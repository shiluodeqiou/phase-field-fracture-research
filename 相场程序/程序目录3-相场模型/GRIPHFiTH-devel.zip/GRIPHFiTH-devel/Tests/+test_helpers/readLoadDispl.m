function [loadDisplTable] = readLoadDispl(fileName)
%READLOADDISPL Read content created with either `phase_field.output.load_displ_line` or
% `phase_field.mex.output.Load_displ_output` calls into a table array.
%   ...
%

% Copyright (C) 2021 ETH Zurich, SIS ID and CompMech D-MAVT
%
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
%
%    http://www.apache.org/licenses/LICENSE-2.0
%
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.

    loadDisplTable = readtable(fileName, 'FileType', 'text');
end
